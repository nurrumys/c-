#include <iostream>
#include <chrono> 


int GCD_modulo(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}


int GCD_subtraction(int a, int b) {
    while (a != b) {
        if (a > b) {
            a -= b;
        }
        else {
            b -= a;
        }
    }
    return a;
}

void compareExecutionTime(int a, int b) {

    auto start_mod = std::chrono::high_resolution_clock::now();
    int gcd_mod = GCD_modulo(a, b);
    auto end_mod = std::chrono::high_resolution_clock::now();
    auto mod_time = std::chrono::duration_cast<std::chrono::nanoseconds>(end_mod - start_mod).count();


    auto start_sub = std::chrono::high_resolution_clock::now();
    int gcd_sub = GCD_subtraction(a, b);
    auto end_sub = std::chrono::high_resolution_clock::now();
    auto sub_time = std::chrono::duration_cast<std::chrono::nanoseconds>(end_sub - start_sub).count();


    std::cout << "GCD_modulo(" << a << ", " << b << ") = " << gcd_mod << ", Time: " << mod_time << " nanoseconds" << std::endl;
    std::cout << "GCD_subtraction(" << a << ", " << b << ") = " << gcd_sub << ", Time: " << sub_time << " nanoseconds" << std::endl;
}

int main() {
    int numbers[][2] = { {103, 3}, {106, 3}, {1010, 3} };

    std::cout << "Execution Time Comparison:\n" << std::endl;
    for (auto& pair : numbers) {
        compareExecutionTime(pair[0], pair[1]);
        std::cout << std::endl;
    }

    return�0;
}